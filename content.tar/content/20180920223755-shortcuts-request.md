Title: 
date: 09/20/2018 12:29
slug: 201809201229-shortcuts-variables
Category: Automation
tags: shortcuts

Siri Functionality in shortcuts is cool, but it would be great to have to have variable placeholders. 

This sorted example shows the difference the second prompt for a date takes on resources and overall time. 
![](https://s3-us-west-2.amazonaws.com/kjaymiller/images/06AC26ED-2F38-4599-9091-CBA688CC2EC9.gif)