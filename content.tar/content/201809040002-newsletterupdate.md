Title: 
date: 09/03/2018 23:51
slug: 201809032351-newsletter
Category: Update
tags: Promotion, newsletter, email, growth
link: https://tinyletter.com/kjaymillerhttps://gph.is/1OZm0mH

Most likely going to have an email going out to the [newsletter](https://tinyletter.com/kjaymiller) every day for the rest of the week. 

It was either that or send a 2,000 word email and that sounds like a nightmare. 

![delete that](https://i.giphy.com/wkKRo7N0T1ONO.gif)

Anyway, if you are interested in Coding (mostly javascript for automation these days), automation, and productivity, why [not subscribe](https://tinyletter.com/kjaymiller). 

## Update
After editing and almost sending todays email (Life Update) I decided it would be better as a [blog post](./life-update-0827-0903). 



