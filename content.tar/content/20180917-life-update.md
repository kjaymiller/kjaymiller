Title: Life Update Sept 17, 2018
date: 09/17/2018 21:39
slug: 201809172139Life-update
Category: Update
tags: IoT, automation, life, daughter

# Life Update 17 Sep 2018
##  Hello World!
I'd like to officially introduce my daughter, JaeAnne Miller, to the world!

![][1]

JaeAnne was born on September 11, 2018. Both Mommy and daughter are healthy and happy. 

## Back Home Blues
We are back home and it is bittersweet. 

We were welcomed back with flowers from my employer (_Thanks, y'all!!_). Baby has been absolutely wonderful. Of course there is crying and long nights but this is to be expected. 

I was also welcomed back home with a notice that my drivers license has been suspended due to a medical condition that causes me to pass out from immense laughter or strain. The DOT hearing upheld that decision and my license will be suspended at least until October 1st when I visit the cardiologist. 🚗 🚫

## IoT Automation
Of course while on paternity leave I will be doing a lot of automation work around the house. This has started with my jump into the IoT space. 

We purchased many hue lights and with the help of HomeKit/iConnect Hue, I've been making some routines around our location and habits. I plan to talk more about that in [my newsletter][2]. 

## ~~Off~~ Working the Next Couple Weeks
While I'm enjoying my new bundle of joy, I am doing a bit of online marketing work for some friends of mine. 

As always, my goal is to be the the voice around the corner of productivity, automation, and community. If you need help with any of those things, feel free to [reach out to me][3]

[1]: https://s3-us-west-2.amazonaws.com/kjaymiller/images/twf89hhg0d77xwt79e3t0bnefv1qc2yd.jpg "JaeAnne"
[2]: https://tinyletter.com/kjaymiller "newsletter"
[3]: https://kjaymiller.github.io/pages/contact.html ""