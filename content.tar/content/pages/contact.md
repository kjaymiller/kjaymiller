Title: I'd Love to Chat with You 💙📥
slug: contact

<div class="row">
<div class="col-md-7">
I'm a pretty open book, but if you have a question or just want to give some feedback. Please fill out the form below... It will go to my email and we can chat.

If you would like to here my thoughts in your inbox regularly, You can also Subscribe to my Newsletter.

Reaching out to me via this form will not add you to any list (except maybe my personal contacts).

<form method="POST" action="https://formspree.io/kjaymiller@gmail.com">
	<br /> <br />  <input type="text" name="Name" placeholder="Your Name" style="width: 30%;">
	<br> <br />  <input type="email" name="email" placeholder="Your email" style="width: 30%;">
	<br /> <br />  <textarea name="message" style="min-width: 50%; height: 150px;" placeholder="Your message"></textarea>
	<br /> <br /> 
	<button type="submit" style="width: 20%;">Send</button>
</form>
  </div>
<div class="col-md-4">
<h2>Email not your thing?</h2>
<p>
You can reach out to me on Twitter.

<a href="https://twitter.com/intent/tweet?screen_name=kjaymiller" class="twitter-mention-button" data-related="prod_in_tech" data-show-count="false">Tweet to @kjaymiller</a><script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></p>
<p> For professional inquiries, Please Visit <a href="https://productivityintech.com">Productivity in Tech</a>.</p>
</div>
</div>
