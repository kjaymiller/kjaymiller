slug: subscribe 
Title: Subscribe to my newsletter! 🗞📨📬

Here are a few things that you will get when you subscribe.

- Updates on all the fun things I'm working on.
- Automation and workflow breakdowns.
- A direct line to me! (Your buddy, your pal!)

<form
	action="https://buttondown.email/api/emails/embed-subscribe/productivityintech"
	method="post"
	target="popupwindow"
	onsubmit="window.open('https://buttondown.email/productivityintech', 'popupwindow')"
	class="col-lg-3 embeddable-buttondown-form">
	<h4 class="font-italic font-weight-strong text-primary"> All this content (plus some extra goodies) in a digestible package in your inbox! </h4> <input type="email"
	name="email"
	placeholder="Email"
	id="bd-email">
	<input type="hidden"
	value="1"
	name="embed" />
	<input class="btn btn-primary my-2"
	type="submit"
	value="Subscribe" />
</form>
