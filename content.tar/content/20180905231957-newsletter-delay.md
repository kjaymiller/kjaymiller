Title: 
date: 09/05/2018 23:06
slug: 201809052306-Newsletter-delay
Category: Update
tags: post

So totally got lazy and didn't finish newsletter post until just now. 

![](https://i.giphy.com/media/InPcMOYXEvXAQ/giphy.gif)

Still need to get a couple more images from work computer so it should be out tomorrow morning.

![](https://s3-us-west-2.amazonaws.com/kjaymiller/images/9335CF6E-55FA-400E-933D-FFAC3F2FBF44.jpeg)

That gives you a chance to [subscribe](https://tinyletter.com/kjaymiller) if you haven't already. 