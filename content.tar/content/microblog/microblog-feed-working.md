The microblog feed seems to be working now. This should be the last test.
