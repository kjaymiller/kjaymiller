Title: 
date: 06/19/2018 09:29
slug: 201806190929-mental-health-newsletter
Category: MicroBlogging
tags: Mental-health, logging

Today's #AutomateADay is on using Drafts as a mood journal 😡🙁😑😶😐🙂😄. 

I have some ideas for covering my mental health, but I need to make sure that I'm logging my for myself. This will help with that. 

Should be out tonight! So [subscribe](https://tinyletter.com/kjaymiller)! 