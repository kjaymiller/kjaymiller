Title: My Personal Youtube Channel is Alive!!
date: 06/19/2018 19:47
slug: 201806191947-youtube-channel
Category: Update
tags: YouTube, video, automations, content creation 

I've been creating some videos regarding the automations that I cover in the [newsletter](https://tinyletter.com/kjaymiller). 

I'm also going to be publishing other videos to it as well, including some upcoming interviews.

I'm doing all of this under my own name so be sure to subscribe to my [personal channel](https://www.youtube.com/channel/UCjoJU65IbXkKXsNqydro05Q). 

Meanwhile here is the latest automation video I put up earlier today!

<iframe width="560" height="315" src="https://www.youtube.com/embed/jmXXUQ-LLkg" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>